import java.util.Arrays;

public class Main {
   public static void main(String args[]) {
      String[] Arr = {"Viks", "Nischchay", "Vivek"};
      int size = Arr.length;

      for(int i = 0; i<size-1; i++) {
         for (int j = i+1; j<Arr.length; j++) {
            if(Arr[i].compareTo(Arr[j])>0) {
               String temp = Arr[i];
               Arr[i] = Arr[j];
               Arr[j] = temp;
            }
         }
      }
      System.out.println(Arrays.toString(Arr));
   }
}