 import java.util.*; 
  
public class Main { 
    public static void main(String args[]) 
    { 
  
         ArrayList<String> l = new ArrayList<String>(); 
  
       
        l.add("Viks"); 
        l.add("Vinayak"); 
        l.add("Nishchay"); 
        l.add("Sneha"); 
        l.add("Vivek"); 
  
        
        System.out.println("Unsorted ArrayList: " + l); 
 
        Collections.sort(l); 
  
        
        System.out.println("Sorted ArrayList "  + l); 
    } 
} 